package tools

func Hello() string {
	return "hello 1"
}
