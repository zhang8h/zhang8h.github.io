package main

import (
	"fmt"
	"my/demo/tools"
	"my/utils"
)

func main() {
	fmt.Println(tools.Hello())
	fmt.Println(utils.Hello())
}
