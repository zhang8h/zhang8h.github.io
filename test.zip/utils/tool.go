package utils

func Hello() string {
	return "hello 2"
}
